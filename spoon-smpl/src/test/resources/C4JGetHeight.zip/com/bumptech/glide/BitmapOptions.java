package com.bumptech.glide;

interface BitmapOptions {

    GenericRequestBuilder<?, ?, ?, ?> fitCenter();

    GenericRequestBuilder<?, ?, ?, ?> centerCrop();

}
