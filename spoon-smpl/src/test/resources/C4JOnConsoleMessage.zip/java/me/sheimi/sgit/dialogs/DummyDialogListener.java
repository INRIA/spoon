package me.sheimi.sgit.dialogs;

import android.content.DialogInterface;

/**
 * Created by sheimi on 8/20/13.
 */
public class DummyDialogListener implements DialogInterface.OnClickListener {
    @Override
    public void onClick(DialogInterface dialogInterface, int i) {
    }
}
