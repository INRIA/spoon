package me.sheimi.sgit.exception;

public class StopTaskException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
