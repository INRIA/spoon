package com.manichord.mgit.repolist

import com.manichord.mgit.common.BaseViewModel

class RepoListViewModel : BaseViewModel() {

}
