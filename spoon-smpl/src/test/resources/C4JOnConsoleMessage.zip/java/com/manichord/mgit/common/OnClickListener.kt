package com.manichord.mgit.common;

interface OnClickListener {
    fun onClick()
}
