package com.manichord.mgit.common;

/**
 * For your list item on click listening pleasure
 *
 */
interface OnActionClickListener {
    fun onActionClick(action : String)
}
