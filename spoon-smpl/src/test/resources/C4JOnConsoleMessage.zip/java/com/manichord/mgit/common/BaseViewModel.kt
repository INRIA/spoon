package com.manichord.mgit.common

import android.arch.lifecycle.ViewModel

abstract class BaseViewModel : ViewModel()
