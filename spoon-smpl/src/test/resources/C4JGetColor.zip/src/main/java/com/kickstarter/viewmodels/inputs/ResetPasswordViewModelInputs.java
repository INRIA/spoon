package com.kickstarter.viewmodels.inputs;

public interface ResetPasswordViewModelInputs {
  void email(String __);
  void resetPasswordClick();
}
