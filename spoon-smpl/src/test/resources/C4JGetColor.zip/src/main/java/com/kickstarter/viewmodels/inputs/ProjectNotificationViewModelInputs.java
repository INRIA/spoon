package com.kickstarter.viewmodels.inputs;

public interface ProjectNotificationViewModelInputs {
  void switchClick(boolean checked);
}
