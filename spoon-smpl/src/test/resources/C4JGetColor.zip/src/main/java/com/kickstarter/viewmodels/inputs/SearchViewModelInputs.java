package com.kickstarter.viewmodels.inputs;

public interface SearchViewModelInputs {
  void search(String __);
  void nextPage();
}
