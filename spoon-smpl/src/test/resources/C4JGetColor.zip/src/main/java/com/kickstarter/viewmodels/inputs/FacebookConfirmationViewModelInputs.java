package com.kickstarter.viewmodels.inputs;

public interface FacebookConfirmationViewModelInputs {
  void createNewAccountClick();
  void fbAccessToken(String __);
  void sendNewslettersClick(boolean __);
}
