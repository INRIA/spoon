package com.kickstarter.viewmodels.inputs;

public interface LoginViewModelInputs {
  void email(String __);
  void loginClick();
  void password(String __);
}
