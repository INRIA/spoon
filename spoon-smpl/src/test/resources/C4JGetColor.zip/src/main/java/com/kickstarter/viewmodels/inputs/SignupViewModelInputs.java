package com.kickstarter.viewmodels.inputs;

public interface SignupViewModelInputs {
  void fullName(String __);
  void email(String __);
  void password(String __);
  void sendNewslettersClick(boolean __);
  void signupClick();
}
