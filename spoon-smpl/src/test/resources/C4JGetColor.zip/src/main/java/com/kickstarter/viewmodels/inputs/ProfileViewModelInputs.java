package com.kickstarter.viewmodels.inputs;

public interface ProfileViewModelInputs {
  void nextPage();
}
