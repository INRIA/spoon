package com.kickstarter.viewmodels;

import com.kickstarter.libs.ViewModel;
import com.kickstarter.ui.activities.HelpActivity;

public final class HelpViewModel extends ViewModel<HelpActivity> {
}
