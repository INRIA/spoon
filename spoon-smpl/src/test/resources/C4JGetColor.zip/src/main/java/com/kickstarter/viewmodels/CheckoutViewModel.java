package com.kickstarter.viewmodels;

import com.kickstarter.libs.ViewModel;
import com.kickstarter.ui.activities.CheckoutActivity;

public final class CheckoutViewModel extends ViewModel<CheckoutActivity> {
}
