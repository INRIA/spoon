package org.thoughtcrime.securesms;

public interface Unbindable {
  public void unbind();
}
