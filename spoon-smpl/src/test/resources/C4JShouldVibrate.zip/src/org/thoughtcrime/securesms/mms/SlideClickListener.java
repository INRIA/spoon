package org.thoughtcrime.securesms.mms;

import android.view.View;

public interface SlideClickListener {
  void onClick(View v, Slide slide);
}
