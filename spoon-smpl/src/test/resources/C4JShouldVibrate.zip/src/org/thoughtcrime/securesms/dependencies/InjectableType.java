package org.thoughtcrime.securesms.dependencies;

public interface InjectableType {
}
