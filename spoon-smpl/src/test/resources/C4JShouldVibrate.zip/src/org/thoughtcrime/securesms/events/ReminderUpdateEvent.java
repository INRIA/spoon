package org.thoughtcrime.securesms.events;


public class ReminderUpdateEvent {
}
