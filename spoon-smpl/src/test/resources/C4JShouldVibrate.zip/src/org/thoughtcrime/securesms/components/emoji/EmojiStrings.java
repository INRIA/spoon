package org.thoughtcrime.securesms.components.emoji;

public final class EmojiStrings {
  public static final String BUST_IN_SILHOUETTE = "\uD83D\uDC64";
}
