package com.powerpoint45.lucidbrowser;

public class ActivityIds {
	public static final int REQUEST_OPEN_BOOKMARK = 2323;
	static final int REQUEST_PICK_BOOKMARK = 458;
	static final int REQUEST_PICK_FILE = 112;
	static final int REQUEST_OPEN_SETTINGS = 324;
}
